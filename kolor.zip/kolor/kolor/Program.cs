﻿using System;

namespace AplikacjaKonsolowa
{
    class Notatka
    {
        public string tytul;
        public string tresc;
        public bool priorytet;  
        public DateTime dataDodania;

        public Notatka(string tytul, string tresc, bool priorytet)
        {
            this.tytul = tytul;
            this.tresc = tresc;
            this.priorytet = priorytet;
            this.dataDodania = DateTime.Now;
        }

        public Notatka(string tytul)
        {
            this.tytul = tytul;
            this.tresc = "";
            this.priorytet = false;
            this.dataDodania = DateTime.Now;
        }


        public void Wypisz()
        {
            Console.WriteLine("____________________________________");
            if (this.priorytet)
            {
                Console.WriteLine($"Notatka WAŻNA! {this.tytul}");
            }
            else
            {
                Console.WriteLine($"Notatka {this.tytul}");
            }
            Console.WriteLine(this.tresc);
            Console.WriteLine(this.dataDodania.ToString("dd.MM.yyyy HH:mm:ss"));
            Console.WriteLine("____________________________________");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Notatka notatka1 = new Notatka("tenis", "Gra z Ewą w poniedziałek", true);

            Console.Write("Podaj tytuł notatki: ");
            string podanyTytul = Console.ReadLine();

            Notatka notatka2 = new Notatka(podanyTytul);

            notatka1.Wypisz();
            notatka2.Wypisz();

            Console.ReadKey();
        }
    }
}
