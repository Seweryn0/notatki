package com.example.notatki;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Notatka> listaNotatek;
    private ArrayAdapter<Notatka> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listViewNotatki = findViewById(R.id.listViewNotatki);
        final EditText editTextTytul = findViewById(R.id.editTextTytul);
        final EditText editTextTresc = findViewById(R.id.editTextTresc);
        Button buttonDodaj = findViewById(R.id.buttonDodaj);

        listaNotatek = new ArrayList<>();
        listaNotatek.add(new Notatka("tenis", "Gra z Ewą w poniedziałek", false));

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaNotatek);
        listViewNotatki.setAdapter(adapter);

        buttonDodaj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tytul = editTextTytul.getText().toString().trim();
                String tresc = editTextTresc.getText().toString().trim();

                if (!tytul.isEmpty()) {
                    Notatka nowaNotatka = new Notatka(tytul, tresc, false);

                    listaNotatek.add(nowaNotatka);

                    adapter.notifyDataSetChanged();

                    editTextTytul.setText("");
                    editTextTresc.setText("");
                }
            }
        });
    }
}
