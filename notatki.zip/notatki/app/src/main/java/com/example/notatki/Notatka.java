package com.example.notatki;

import java.time.LocalDate;

public class Notatka {
    public String tytul;
    public String tresc;
    public boolean priorytet;
    public LocalDate dataDodania;

    public Notatka(String tytul, String tresc, boolean priorytet) {
        this.tytul = tytul;
        this.tresc = tresc;
        this.priorytet = priorytet;
        this.dataDodania = LocalDate.now();
    }

    public Notatka(String tytul) {
        this.tytul = tytul;
        this.tresc = "";
        this.priorytet = false;
        this.dataDodania = LocalDate.now();
    }

    @Override
    public String toString() {
        return tytul + "\n" + tresc;
    }
}
